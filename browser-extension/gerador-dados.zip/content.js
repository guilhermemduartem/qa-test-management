/* ═══════════════════════════════════════════════════════════════════════════
   Gerador de Dados — content script
   Injeta uma bolinha flutuante (FAB) em qualquer página, com painel para gerar
   CPF / RG / CNPJ / Passaporte. Tudo isolado em Shadow DOM para não conflitar
   com o CSS do site. Geradores portados de src/lib/generators.ts do QAReporter.
   ═══════════════════════════════════════════════════════════════════════════ */
(() => {
  'use strict';
  if (window.__cpfFabInjected) return;
  window.__cpfFabInjected = true;
  console.log('[Gerador de Dados] content script ativo em', location.href);

  /* ───────────────────────── Geradores (puros) ───────────────────────── */
  function gerarCPF() {
    const d = [];
    for (let i = 0; i < 9; i++) d.push(Math.floor(Math.random() * 10));
    let soma = 0;
    for (let i = 0; i < 9; i++) soma += d[i] * (10 - i);
    let resto = soma % 11;
    d.push(resto < 2 ? 0 : 11 - resto);
    soma = 0;
    for (let i = 0; i < 10; i++) soma += d[i] * (11 - i);
    resto = soma % 11;
    d.push(resto < 2 ? 0 : 11 - resto);
    return d.join('');
  }
  const formatarCPF = (cpf, m) => (m ? cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : cpf);

  function randomCnpjChar() {
    const pool = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return pool[Math.floor(Math.random() * pool.length)];
  }
  function cnpjCharValue(ch) {
    const code = ch.charCodeAt(0);
    if (code >= 48 && code <= 57) return code - 48;
    if (code >= 65 && code <= 90) return code - 48;
    if (code >= 97 && code <= 122) return ch.toUpperCase().charCodeAt(0) - 48;
    return 0;
  }
  function calcularDvCnpj(base) {
    let soma = 0, peso = 5;
    for (let i = 0; i < base.length; i++) { soma += cnpjCharValue(base[i]) * peso; peso = peso === 2 ? 9 : peso - 1; }
    let resto = soma % 11;
    const dv1 = resto < 2 ? 0 : 11 - resto;
    soma = 0; peso = 6;
    const full = base + String(dv1);
    for (let i = 0; i < full.length; i++) { soma += cnpjCharValue(full[i]) * peso; peso = peso === 2 ? 9 : peso - 1; }
    resto = soma % 11;
    const dv2 = resto < 2 ? 0 : 11 - resto;
    return `${dv1}${dv2}`;
  }
  function gerarCNPJ(alfa) {
    const base = alfa
      ? Array.from({ length: 12 }, () => randomCnpjChar()).join('')
      : Array.from({ length: 12 }, () => String(Math.floor(Math.random() * 10))).join('');
    return base + calcularDvCnpj(base);
  }
  function formatarCNPJ(cnpj, m) {
    if (!m) return cnpj;
    const c = String(cnpj || '').replace(/[^0-9A-Za-z]/g, '').toUpperCase();
    if (c.length !== 14) return cnpj;
    return `${c.slice(0, 2)}.${c.slice(2, 5)}.${c.slice(5, 8)}/${c.slice(8, 12)}-${c.slice(12, 14)}`;
  }

  function gerarRG() {
    let rg = '';
    for (let i = 0; i < 8; i++) rg += Math.floor(Math.random() * 10);
    let soma = 0, peso = 2;
    for (let i = 0; i < 8; i++) { soma += parseInt(rg[i], 10) * peso; peso++; }
    const resto = soma % 11;
    let dig = resto === 0 ? 0 : 11 - resto;
    if (dig === 10) dig = 'X';
    return rg + dig;
  }
  const formatarRG = (rg, m) => (m ? rg.replace(/(\d{2})(\d{3})(\d{3})(\w{1})/, '$1.$2.$3-$4') : rg);

  const LETRAS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const rndLetra = () => LETRAS[Math.floor(Math.random() * LETRAS.length)];
  const rndDig = (n) => Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join('');
  const gerarPassaporteBR = () => `${rndLetra()}${rndLetra()}${rndDig(6)}`;
  const gerarPassaporteInternacional = () => `${rndLetra()}${rndLetra()}${rndDig(7)}`;

  function gen(tab, mask, alfa, passSub) {
    if (tab === 'cpf') return formatarCPF(gerarCPF(), mask);
    if (tab === 'rg') return formatarRG(gerarRG(), mask);
    if (tab === 'cnpj') return formatarCNPJ(gerarCNPJ(alfa), mask);
    return passSub === 'br' ? gerarPassaporteBR() : gerarPassaporteInternacional();
  }

  /* ───────────────────────── Estado ───────────────────────── */
  const FAB = 58;
  const TABS = [['cpf', 'CPF'], ['rg', 'RG'], ['cnpj', 'CNPJ'], ['passaporte', 'Passaporte']];
  const st = { tab: 'cpf', mask: true, alfa: false, passSub: 'br', value: '', open: false, hidden: false };
  let pos = { bottom: 28, right: 28 };
  const drag = { active: false, startX: 0, startY: 0, startBottom: 0, startRight: 0, moved: false };

  function clampPos(b, r) {
    const maxB = window.innerHeight - FAB - 8;
    const maxR = window.innerWidth - FAB - 8;
    return { bottom: Math.max(8, Math.min(b, maxB)), right: Math.max(8, Math.min(r, maxR)) };
  }

  /* persistência (chrome.storage com fallback localStorage) */
  const KEY = 'cpf_fab_state';
  function savePersist() {
    const data = { pos, tab: st.tab, mask: st.mask, alfa: st.alfa, passSub: st.passSub, hidden: st.hidden };
    try { chrome?.storage?.local?.set({ [KEY]: data }); } catch { /**/ }
    try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /**/ }
  }
  function loadPersist(cb) {
    try {
      chrome?.storage?.local?.get([KEY], (r) => {
        const d = r && r[KEY];
        if (d) apply(d);
        else { try { const ls = JSON.parse(localStorage.getItem(KEY) || 'null'); if (ls) apply(ls); } catch { /**/ } }
        cb();
      });
      return;
    } catch { /**/ }
    try { const ls = JSON.parse(localStorage.getItem(KEY) || 'null'); if (ls) apply(ls); } catch { /**/ }
    cb();
    function apply(d) {
      if (d.pos) pos = d.pos;
      if (d.tab) st.tab = d.tab;
      if (typeof d.mask === 'boolean') st.mask = d.mask;
      if (typeof d.alfa === 'boolean') st.alfa = d.alfa;
      if (d.passSub) st.passSub = d.passSub;
      if (typeof d.hidden === 'boolean') st.hidden = d.hidden;
    }
  }

  /* ───────────────────────── DOM / Shadow ───────────────────────── */
  const host = document.createElement('div');
  host.id = 'cpf-fab-host';
  host.style.cssText = 'position:fixed; top:0; left:0; width:0; height:0; z-index:2147483647;';
  function mountHost() { (document.body || document.documentElement).appendChild(host); }
  if (document.body) mountHost();
  else document.addEventListener('DOMContentLoaded', mountHost, { once: true });
  const root = host.attachShadow({ mode: 'open' });

  const ACCENT = '#6366f1', ACCENT_DARK = '#4f46e5';
  const style = document.createElement('style');
  style.textContent = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; }
    .fab {
      position: fixed; width: ${FAB}px; height: ${FAB}px; border-radius: 50%;
      background: ${ACCENT}; color: #fff; border: none; cursor: grab;
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 4px 20px rgba(0,0,0,.32); z-index: 2147483647;
      transition: transform .18s, box-shadow .18s, background .18s;
    }
    .fab:hover { transform: scale(1.09); box-shadow: 0 6px 24px rgba(0,0,0,.34); }
    .fab.open { background: ${ACCENT_DARK}; }
    .fab svg { pointer-events: none; width: 24px; height: 24px; }
    .panel {
      position: fixed; width: 320px; background: #1e1e2e; border: 1px solid #33334d;
      border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,.45); z-index: 2147483646;
      overflow: hidden; color: #e6e6f0; animation: in .18s ease;
    }
    @keyframes in { from { opacity: 0; transform: translateY(8px) scale(.98); } to { opacity: 1; transform: none; } }
    .ph { display: flex; align-items: center; justify-content: space-between; padding: 11px 14px; background: ${ACCENT}; color: #fff; font-weight: 600; font-size: 13px; }
    .ph-l { display: flex; align-items: center; gap: 8px; }
    .ph svg { width: 18px; height: 18px; }
    .close { background: none; border: none; color: rgba(255,255,255,.75); cursor: pointer; font-size: 15px; line-height: 1; padding: 2px 6px; border-radius: 4px; }
    .close:hover { color: #fff; background: rgba(255,255,255,.15); }
    .tabs { display: flex; background: #26263a; border-bottom: 1px solid #33334d; }
    .tab { flex: 1; padding: 9px 0; background: none; border: none; border-bottom: 2px solid transparent; cursor: pointer; font-size: 12.5px; font-weight: 600; color: #8a8a9a; letter-spacing: .3px; }
    .tab.active { color: ${ACCENT}; border-bottom-color: ${ACCENT}; }
    .tab:hover:not(.active) { color: #e6e6f0; }
    .body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
    .value { font-family: 'SFMono-Regular', Consolas, monospace; font-size: 19px; font-weight: 700; color: #fff; text-align: center; padding: 14px 10px; background: #14141f; border-radius: 10px; border: 1px solid #33334d; letter-spacing: 1.5px; min-height: 52px; display: flex; align-items: center; justify-content: center; user-select: all; word-break: break-all; }
    .actions { display: flex; gap: 8px; }
    .btn { flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 5px; padding: 8px; border-radius: 8px; border: 1px solid #33334d; background: #26263a; color: #b8b8c8; font-size: 12px; font-weight: 500; cursor: pointer; }
    .btn:hover { background: #2d2d44; color: #fff; }
    .btn svg { width: 14px; height: 14px; }
    .btn-copy.copied { background: rgba(34,197,94,.14); color: #4ade80; border-color: rgba(34,197,94,.4); }
    .options { display: flex; gap: 16px; flex-wrap: wrap; }
    .toggle { display: flex; align-items: center; gap: 6px; font-size: 12px; color: #8a8a9a; cursor: pointer; user-select: none; }
    .toggle input { cursor: pointer; accent-color: ${ACCENT}; width: 14px; height: 14px; }
    .seg { display: flex; border: 1px solid #33334d; border-radius: 8px; overflow: hidden; background: #26263a; }
    .seg-btn { flex: 1; padding: 7px 10px; background: none; border: none; border-right: 1px solid #33334d; font-size: 12px; font-weight: 500; color: #8a8a9a; cursor: pointer; }
    .seg-btn:last-child { border-right: none; }
    .seg-btn.active { background: ${ACCENT}; color: #fff; }
    .seg-btn:not(.active):hover { background: #2d2d44; color: #fff; }
    .pass-info { font-size: 11px; color: #8a8a9a; text-align: center; }
    .pass-info em { opacity: .75; }
    .hidden { display: none !important; }
  `;
  root.appendChild(style);

  const ICON_WRENCH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>';
  const ICON_COPY = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
  const ICON_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
  const ICON_REFRESH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>';

  const wrap = document.createElement('div');
  root.appendChild(wrap);

  function render() {
    const showMask = st.tab !== 'passaporte';
    const showAlfa = st.tab === 'cnpj';
    const showPass = st.tab === 'passaporte';
    const panelBottom = pos.bottom + FAB + 10;

    wrap.innerHTML = `
      ${st.open ? `
      <div class="panel" style="bottom:${panelBottom}px; right:${pos.right}px;">
        <div class="ph">
          <div class="ph-l">${ICON_WRENCH}<span>Gerador de Dados</span></div>
          <button class="close" data-act="close" title="Fechar">✕</button>
        </div>
        <div class="tabs">
          ${TABS.map(([k, l]) => `<button class="tab${st.tab === k ? ' active' : ''}" data-tab="${k}">${l}</button>`).join('')}
        </div>
        <div class="body">
          ${showPass ? `
          <div class="seg">
            <button class="seg-btn${st.passSub === 'br' ? ' active' : ''}" data-pass="br">🇧🇷 Brasil</button>
            <button class="seg-btn${st.passSub === 'internacional' ? ' active' : ''}" data-pass="internacional">🌐 Internacional</button>
          </div>
          <div class="pass-info">${st.passSub === 'br' ? '2 letras + 6 dígitos <em>(padrão BR desde 2010)</em>' : '2 letras + 7 dígitos <em>(padrão ICAO 9303)</em>'}</div>
          ` : ''}
          <div class="value">${st.value}</div>
          <div class="actions">
            <button class="btn btn-copy" data-act="copy">${ICON_COPY} Copiar</button>
            <button class="btn" data-act="regen">${ICON_REFRESH} Gerar novo</button>
          </div>
          ${(showMask || showAlfa) ? `
          <div class="options">
            ${showMask ? `<label class="toggle"><input type="checkbox" data-act="mask" ${st.mask ? 'checked' : ''}> Com máscara</label>` : ''}
            ${showAlfa ? `<label class="toggle"><input type="checkbox" data-act="alfa" ${st.alfa ? 'checked' : ''}> Com letras</label>` : ''}
          </div>` : ''}
        </div>
      </div>` : ''}
      <button class="fab${st.open ? ' open' : ''} ${st.hidden ? 'hidden' : ''}" style="bottom:${pos.bottom}px; right:${pos.right}px;" title="Gerador de dados (arraste para mover)">${ICON_WRENCH}</button>
    `;
    bind();
  }

  function regen() { st.value = gen(st.tab, st.mask, st.alfa, st.passSub); render(); }

  async function copyValue(btn) {
    const text = st.value;
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch { /**/ }
    if (!ok) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove();
      } catch { /**/ }
    }
    if (ok && btn) {
      btn.classList.add('copied');
      btn.innerHTML = `${ICON_CHECK} Copiado`;
      setTimeout(() => { btn.classList.remove('copied'); btn.innerHTML = `${ICON_COPY} Copiar`; }, 1600);
    }
  }

  function bind() {
    const fab = wrap.querySelector('.fab');
    if (fab) {
      fab.addEventListener('pointerdown', onFabDown);
      fab.addEventListener('click', onFabClick);
    }
    wrap.querySelectorAll('[data-tab]').forEach((el) =>
      el.addEventListener('click', () => { st.tab = el.dataset.tab; regen(); savePersist(); }));
    wrap.querySelectorAll('[data-pass]').forEach((el) =>
      el.addEventListener('click', () => { st.passSub = el.dataset.pass; regen(); savePersist(); }));
    const close = wrap.querySelector('[data-act="close"]');
    if (close) close.addEventListener('click', () => { st.open = false; render(); });
    const copy = wrap.querySelector('[data-act="copy"]');
    if (copy) copy.addEventListener('click', () => copyValue(copy));
    const re = wrap.querySelector('[data-act="regen"]');
    if (re) re.addEventListener('click', regen);
    const mask = wrap.querySelector('[data-act="mask"]');
    if (mask) mask.addEventListener('change', () => { st.mask = mask.checked; regen(); savePersist(); });
    const alfa = wrap.querySelector('[data-act="alfa"]');
    if (alfa) alfa.addEventListener('change', () => { st.alfa = alfa.checked; regen(); savePersist(); });
  }

  function onFabDown(e) {
    drag.active = true; drag.moved = false;
    drag.startX = e.clientX; drag.startY = e.clientY;
    drag.startBottom = pos.bottom; drag.startRight = pos.right;
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /**/ }
  }
  function onFabClick() {
    if (drag.moved) return;
    st.open = !st.open;
    if (st.open) regen(); else render();
  }
  document.addEventListener('pointermove', (e) => {
    if (!drag.active) return;
    const dx = e.clientX - drag.startX, dy = e.clientY - drag.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) drag.moved = true;
    if (!drag.moved) return;
    pos = clampPos(drag.startBottom - dy, drag.startRight - dx);
    const fab = wrap.querySelector('.fab');
    if (fab) { fab.style.bottom = pos.bottom + 'px'; fab.style.right = pos.right + 'px'; }
    const panel = wrap.querySelector('.panel');
    if (panel) { panel.style.bottom = (pos.bottom + FAB + 10) + 'px'; panel.style.right = pos.right + 'px'; }
  });
  document.addEventListener('pointerup', () => {
    if (drag.active && drag.moved) savePersist();
    drag.active = false;
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st.open) { st.open = false; render(); } });
  document.addEventListener('mousedown', (e) => {
    if (!st.open) return;
    const path = e.composedPath ? e.composedPath() : [];
    if (path.includes(host)) return;
    st.open = false; render();
  });

  /* toggle de visibilidade vindo do clique no ícone da extensão */
  try {
    chrome?.runtime?.onMessage?.addListener((msg) => {
      if (msg && msg.type === 'TOGGLE_FAB') { st.hidden = !st.hidden; if (st.hidden) st.open = false; render(); savePersist(); }
    });
  } catch { /**/ }

  // Render imediato (não depende do storage) — garante que a bolinha apareça.
  try {
    st.value = gen(st.tab, st.mask, st.alfa, st.passSub);
    pos = clampPos(pos.bottom, pos.right);
    render();
    console.log('[Gerador de Dados] bolinha renderizada; host no DOM?', !!host.isConnected, '| fab?', !!root.querySelector('.fab'));
  } catch (err) {
    console.error('[Gerador de Dados] erro ao renderizar:', err);
  }

  // Hidrata estado salvo e re-renderiza (se disponível).
  try {
    loadPersist(() => { st.value = gen(st.tab, st.mask, st.alfa, st.passSub); pos = clampPos(pos.bottom, pos.right); render(); });
  } catch (err) { /* ignora — já renderizou com defaults */ }
})();
