/* Clicar no ícone da extensão mostra/oculta a bolinha na aba atual. */
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_FAB' }).catch(() => {
    /* aba sem content script (ex.: páginas internas chrome://) — ignora */
  });
});
